/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80100
 Source Host           : localhost:3306
 Source Schema         : health

 Target Server Type    : MySQL
 Target Server Version : 80100
 File Encoding         : 65001

 Date: 13/06/2025 00:05:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for detail
-- ----------------------------
DROP TABLE IF EXISTS `detail`;
CREATE TABLE `detail`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `sport_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `disease` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `method` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `notes` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of detail
-- ----------------------------
INSERT INTO `detail` VALUES (1, '越野跑', '心脏病', '适度运动，不要剧烈运动，保持心情愉快', '避免在气温过高或过低的环境下运动');
INSERT INTO `detail` VALUES (2, '太极拳', '高血压', '轻柔的动作，缓慢而稳定的呼吸', '保持心情平稳，不要过度紧张');
INSERT INTO `detail` VALUES (3, '快跑', '关节炎', '选择跑步道或软质地面进行，适当热身', '避免过度的冲击力，注意饮食');
INSERT INTO `detail` VALUES (4, '慢跑', '哮喘', '避免在雾霾天气、气温过高或过低的环境下运动', '控制呼吸，使用合适的防护装备');
INSERT INTO `detail` VALUES (6, '抖空竹', '眼疾', '注意眼睛的休息和保护，不要盯着空竹太久', '避免在光线昏暗的环境下玩抖空竹');
INSERT INTO `detail` VALUES (7, '抽陀螺', '高血压', '避免剧烈运动，不要在悬崖陡坡等高度场所运动', '避免在气温过高或过低的环境下运动');
INSERT INTO `detail` VALUES (8, '拔河', '心脏病', '注意不要过度用力，保持呼吸稳定', '人数相对平衡，避免人数不足或过多');
INSERT INTO `detail` VALUES (9, '排球', '扭伤', '注意热身，保持肌肉灵活', '避免在硬地面和湿滑地面上运动，注意落地姿势');
INSERT INTO `detail` VALUES (10, '放风筝', '过敏性鼻炎', '避免在花粉高发季节和污染严重的地区放风筝', '选择空气清新的场地，不要在风力过大的环境下放风筝');
INSERT INTO `detail` VALUES (11, '橄榄球', '骨折', '选择合适的防护装备，不要使用过度生硬的球', '规范比赛流程，避免激烈对抗');
INSERT INTO `detail` VALUES (12, '游泳', '心脏病、心律失常、哮喘、高血压', '游泳是一项全身性运动，但对于患有心脏病、心律失常、哮喘等疾病的人来说，游泳容易加重病情，甚至引发突发病情，因此应该避免。而患有高血压的人可以适当游泳，但是游泳时间和强度不宜过大。', '游泳时一定要注意安全，避免溺水事故的发生；同时注意保持游泳池的清洁卫生，避免感染泳池病毒。');
INSERT INTO `detail` VALUES (13, '滑冰', '骨折、关节炎、心脏病、高血压', '滑冰是一项高风险运动，容易导致骨折、关节炎等损伤，对于患有心脏病、高血压等疾病的人来说，也需要注意保护自己，避免剧烈运动。', '滑冰时要穿好防护装备，注意自己的身体状况，避免过度运动造成身体损伤。');
INSERT INTO `detail` VALUES (14, '爬山', '高血压、心脏病、脑血管疾病', '选择较平缓的山路，避免过于陡峭的路段；掌握正确的呼吸方法，避免缺氧；', '切勿贪多嚼不烂，随时可以补充水分和能量；注意天气变化，避免在大雾、大风、雷雨天气攀登；');
INSERT INTO `detail` VALUES (15, '瑜伽', '脊椎病、膝盖受伤、关节病变', '选择适合自己身体情况的瑜伽动作；呼吸要自然流畅，不要憋气或过度呼吸；动作要准确，避免造成不必要的压力或伤害；', '练习前应注意饮食、排便，不宜在空腹或饱腹时练习；练习时注意周围环境，保持安静的氛围；练习后应适当休息，以便身体恢复；');
INSERT INTO `detail` VALUES (16, '篮球', '心脏病、脑血管疾病、骨折', '保持适度的身体活动，不要过度用力；掌握正确的篮球技巧，避免不必要的伤害；在比赛中要遵守规则，注意安全；', '合理安排练球时间和强度，不要过度训练；练球时应注意防护措施，如佩戴护具等；注意饮食，保证充足的营养摄入；');
INSERT INTO `detail` VALUES (17, '网球', '肩部受伤、腕关节疼痛、脱臼', '掌握正确的发球姿势和击球技巧；加强肌肉的训练，提高关节的灵活性；注意休息，避免过度疲劳；', '选择合适的球拍和鞋子，避免不必要的伤害；保持场地干燥，防止滑倒；定期进行身体检查，及时发现问题；');
INSERT INTO `detail` VALUES (18, '羽毛球', '肌肉劳损', '逐渐增加训练量，充足的热身与休息，避免过度用力', '注意营养、充足的睡眠，避免疲劳、缺氧');
INSERT INTO `detail` VALUES (19, '越野跑', '膝盖疼痛', '选择软质路面，加强膝关节周围肌肉的锻炼', '注意营养、饮食的平衡，避免过度减重、缺氧');
INSERT INTO `detail` VALUES (20, '足球', '膝盖疼痛', '选择软质路面，加强膝关节周围肌肉的锻炼', '注意营养、饮食的平衡，避免过度减重、缺氧');
INSERT INTO `detail` VALUES (21, '跆拳道', '扭伤、拉伤', '逐渐增加训练量，充足的热身与休息，避免过度用力', '注意营养、充足的睡眠，避免疲劳、缺氧');
INSERT INTO `detail` VALUES (22, '跑步', '膝盖疼痛', '选择软质路面，加强膝关节周围肌肉的锻炼', '注意营养、饮食的平衡，避免过度减重、缺氧');
INSERT INTO `detail` VALUES (23, '跳板', '脊椎损伤', '注意技术细节，逐渐增加训练难度，避免过度用力', '可选择针对脊柱的力量训练，加强腰背肌群的锻炼');
INSERT INTO `detail` VALUES (24, '跳皮筋', '肌肉劳损', '逐渐增加训练量，充足的热身与休息，避免过度用力', '注意营养、充足的睡眠，避免疲劳、缺氧');
INSERT INTO `detail` VALUES (25, '跳绳', '膝盖或脚踝疼痛、肌肉酸痛、运动损伤', '手持跳绳，双脚交替跳跃，以规定时间内跳跃次数最多者获胜。', '需要注意跳绳时的姿势和呼吸。');
INSERT INTO `detail` VALUES (26, '跳高', '扭伤、肌肉拉伤、腰椎间盘突出、关节炎', '又称跳高栏，运动员在助跑后跳过竞赛高度悬挂的水平杠，以完成跳高动作，高度逐渐升高，未能过去的选手则被淘汰。', '需要注意跳高时的跑道、助跑和跳跃姿势。');
INSERT INTO `detail` VALUES (27, '踢毽子', '扭伤、拉伤', '将毽子踢起来并在空中进行一系列动作，规定时间内完成动作最多的人获胜。', '需要注意毽子的质量和天气情况。');
INSERT INTO `detail` VALUES (28, '长跑', '心脏病、高血压、哮喘、慢性阻塞性肺疾病', '一项有氧耐力运动，比赛时要跑过规定的路程，规定时间内到达终点的人获胜。', '需要注意长跑时的呼吸和水分补给。');

-- ----------------------------
-- Table structure for j_body
-- ----------------------------
DROP TABLE IF EXISTS `j_body`;
CREATE TABLE `j_body`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `age` int NULL DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `height` float NULL DEFAULT NULL,
  `weight` float NULL DEFAULT NULL,
  `bloodSugar` float NULL DEFAULT NULL,
  `bloodPressure` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `bloodLipid` float NULL DEFAULT NULL,
  `heart_rate` decimal(10, 0) NULL DEFAULT NULL,
  `vision` int NULL DEFAULT NULL,
  `sleep_duration` decimal(10, 0) NULL DEFAULT NULL,
  `sleep_quality` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `smoking` tinyint(1) NULL DEFAULT NULL,
  `drinking` tinyint(1) NULL DEFAULT NULL,
  `exercise` tinyint(1) NULL DEFAULT NULL,
  `food_types` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `water_consumption` decimal(10, 0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_body
-- ----------------------------
INSERT INTO `j_body` VALUES (1, 'admin', 18, '男', 1.8, 50, 25, '16', 25, 80, 220, 8, '好', 1, 0, 0, '蔬菜', 1500);
INSERT INTO `j_body` VALUES (32, '111', 21, '男', 185, 95, 20, '180', 20, 90, 200, 0, '差', 1, 1, 0, '肉类', 1000);
INSERT INTO `j_body` VALUES (33, 'zhang', 25, '男', 1.75, 70, 5.2, '120/80', 4.5, 75, 5, 7, '良好', 0, 0, 1, '均衡饮食', 2000);
INSERT INTO `j_body` VALUES (34, 'wang', 30, '女', 1.65, 55, 5, '110/70', 4.2, 68, 5, 8, '良好', 0, 0, 1, '素食为主', 2500);
INSERT INTO `j_body` VALUES (35, 'li', 28, '男', 1.8, 75, 5.5, '125/85', 4.8, 72, 5, 6, '一般', 1, 0, 0, '高蛋白', 1800);
INSERT INTO `j_body` VALUES (36, 'zhao', 22, '女', 1.6, 50, 4.9, '105/65', 4, 65, 5, 9, '良好', 0, 0, 1, '低脂饮食', 2200);
INSERT INTO `j_body` VALUES (37, 'chen', 35, '男', 1.78, 80, 6, '135/90', 5.2, 78, 5, 6, '一般', 1, 1, 0, '高碳水', 1500);
INSERT INTO `j_body` VALUES (38, 'user', 27, '女', 1.68, 58, 5.1, '115/75', 4.3, 70, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2300);

-- ----------------------------
-- Table structure for j_body_notes
-- ----------------------------
DROP TABLE IF EXISTS `j_body_notes`;
CREATE TABLE `j_body_notes`  (
  `notes_id` int NOT NULL AUTO_INCREMENT,
  `id` int NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `age` int NULL DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `height` float NULL DEFAULT NULL,
  `weight` float NULL DEFAULT NULL,
  `bloodSugar` float NULL DEFAULT NULL,
  `bloodPressure` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `bloodLipid` float NULL DEFAULT NULL,
  `heart_rate` decimal(10, 0) NULL DEFAULT NULL,
  `vision` int NULL DEFAULT NULL,
  `sleep_duration` decimal(10, 0) NULL DEFAULT NULL,
  `sleep_quality` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `smoking` tinyint(1) NULL DEFAULT NULL,
  `drinking` tinyint(1) NULL DEFAULT NULL,
  `exercise` tinyint(1) NULL DEFAULT NULL,
  `food_types` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `water_consumption` decimal(10, 0) NULL DEFAULT NULL,
  `Date` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notes_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 73 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_body_notes
-- ----------------------------
INSERT INTO `j_body_notes` VALUES (20, 13, 'Alice', 25, '男', 1.8, 80, 20, '20', 20, 100, 100, 9, '好', 0, 0, 0, '豆类', 3000, '2025-03-15 18:01:06');
INSERT INTO `j_body_notes` VALUES (21, 13, 'Alice', 25, '男', 1.8, 80, 20, '25', 23, 80, 120, 9, '好', 0, 0, 0, '豆类', 3000, '2025-03-13 06:01:52');
INSERT INTO `j_body_notes` VALUES (25, 1, 'admin', 20, '男', 1.7, 56, 10, '15', 20, 80, 20, 10, '好', 1, 1, 1, '鱼类', 1500, '2025-03-14 17:36:29');
INSERT INTO `j_body_notes` VALUES (26, 1, 'admin', 20, '男', 1.7, 56, 8, '13', 20, 120, 50, 10, '好', 1, 1, 1, '鱼类', 1500, '2025-03-14 17:36:31');
INSERT INTO `j_body_notes` VALUES (27, 1, 'admin', 20, '男', 1.7, 56, 15, '20', 20, 70, 65, 10, '好', 1, 1, 1, '鱼类', 1500, '2025-03-13 17:36:32');
INSERT INTO `j_body_notes` VALUES (28, 1, 'admin', 20, '男', 1.7, 56, 21, '8', 20, 80, 75, 10, '好', 1, 1, 1, '鱼类', 1500, '2025-03-16 17:36:34');
INSERT INTO `j_body_notes` VALUES (29, 1, 'admin', 20, '男', 1.7, 56, 15, '10', 20, 110, 80, 10, '好', 1, 1, 1, '鱼类', 1500, '2025-03-12 17:36:38');
INSERT INTO `j_body_notes` VALUES (30, 1, 'admin', 20, '男', 1.7, 56, 17, '16', 20, 75, 120, 10, '好', 1, 1, 1, '鱼类', 1500, '2025-03-11 17:36:40');
INSERT INTO `j_body_notes` VALUES (31, 1, 'admin', 20, '男', 1.7, 56, 8, '25', 20, 130, 150, 10, '好', 1, 1, 1, '鱼类', 1500, '2025-03-15 18:01:06');
INSERT INTO `j_body_notes` VALUES (32, 1, 'admin', 20, '男', 1.7, 56, 11, '7', 20, 80, 150, 10, '好', 0, 0, 0, '鱼类', 1500, '2025-03-13 06:01:52');
INSERT INTO `j_body_notes` VALUES (34, 31, 'test', 18, '男', 1.8, 50, 20, '20', 15, 80, 50, 7, '好', 0, 0, 0, '水果', 2000, '2025-03-14 17:36:29');
INSERT INTO `j_body_notes` VALUES (35, 31, 'test', 18, '男', 1.8, 50, 20, '20', 15, 80, 100, 7, '好', 0, 0, 0, '水果', 2000, '2025-03-14 17:36:31');
INSERT INTO `j_body_notes` VALUES (36, 31, 'test', 18, '男', 1.8, 50, 20, '20', 15, 80, 150, 7, '好', 0, 0, 0, '水果', 2000, '2025-03-13 17:36:32');
INSERT INTO `j_body_notes` VALUES (37, 31, 'test', 18, '男', 1.8, 50, 20, '20', 15, 80, 200, 7, '好', 0, 0, 0, '水果', 2000, '2025-03-16 17:36:34');
INSERT INTO `j_body_notes` VALUES (38, 13, 'Alice', 25, '男', 1.8, 80, 26, '21', 23, 90, 140, 9, '好', 0, 0, 0, '豆类', 3000, '2025-03-12 17:36:38');
INSERT INTO `j_body_notes` VALUES (39, 13, 'Alice', 25, '男', 1.8, 80, 26, '16', 18, 79, 160, 9, '好', 0, 0, 0, '豆类', 3000, '2025-03-11 17:36:40');
INSERT INTO `j_body_notes` VALUES (40, 13, 'Alice', 18, '男', 1.8, 50, 20, '24', 15, 65, 200, 8, '好', 0, 0, 0, '水果', 1500, '2025-03-11 17:36:40');
INSERT INTO `j_body_notes` VALUES (41, 1, 'admin', 18, '男', 1.8, 50, 25, '16', 25, 80, 220, 8, '好', 0, 0, 0, '蔬菜', 1500, '2025-03-11 17:36:40');
INSERT INTO `j_body_notes` VALUES (42, 32, '111', 21, '男', 185, 95, 20, '180', 20, 90, 200, 0, '差', 1, 1, 0, '肉类', 1000, '2025-03-15 22:18:54');
INSERT INTO `j_body_notes` VALUES (43, 33, 'zhang', 25, '男', 1.75, 70, 5.2, '120/80', 4.5, 75, 5, 7, '良好', 0, 0, 1, '均衡饮食', 2000, '2025-03-01 10:15:20');
INSERT INTO `j_body_notes` VALUES (44, 33, 'zhang', 25, '男', 1.75, 69, 5.1, '118/78', 4.4, 74, 5, 7, '良好', 0, 0, 1, '均衡饮食', 2000, '2025-03-08 11:20:30');
INSERT INTO `j_body_notes` VALUES (45, 33, 'zhang', 25, '男', 1.75, 68, 5, '117/77', 4.3, 73, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2100, '2025-03-15 09:30:15');
INSERT INTO `j_body_notes` VALUES (46, 33, 'zhang', 25, '男', 1.75, 67, 5, '115/75', 4.2, 72, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2100, '2025-03-22 10:45:25');
INSERT INTO `j_body_notes` VALUES (47, 33, 'zhang', 25, '男', 1.75, 67, 4.9, '115/75', 4.2, 72, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2200, '2025-03-29 11:10:05');
INSERT INTO `j_body_notes` VALUES (48, 34, 'wang', 30, '女', 1.65, 55, 5, '110/70', 4.2, 68, 5, 8, '良好', 0, 0, 1, '素食为主', 2500, '2025-03-02 14:25:10');
INSERT INTO `j_body_notes` VALUES (49, 34, 'wang', 30, '女', 1.65, 54.5, 4.9, '108/70', 4.1, 67, 5, 8, '良好', 0, 0, 1, '素食为主', 2500, '2025-03-09 15:30:20');
INSERT INTO `j_body_notes` VALUES (50, 34, 'wang', 30, '女', 1.65, 54, 4.9, '108/68', 4.1, 67, 5, 8, '良好', 0, 0, 1, '素食为主', 2600, '2025-03-16 16:15:45');
INSERT INTO `j_body_notes` VALUES (51, 34, 'wang', 30, '女', 1.65, 53.5, 4.8, '107/68', 4, 66, 5, 8, '良好', 0, 0, 1, '素食为主', 2600, '2025-03-23 14:50:30');
INSERT INTO `j_body_notes` VALUES (52, 34, 'wang', 30, '女', 1.65, 53, 4.8, '105/65', 4, 65, 5, 8, '良好', 0, 0, 1, '素食为主', 2700, '2025-03-30 15:40:15');
INSERT INTO `j_body_notes` VALUES (53, 35, 'li', 28, '男', 1.8, 75, 5.5, '125/85', 4.8, 72, 5, 6, '一般', 1, 0, 0, '高蛋白', 1800, '2025-03-03 08:20:15');
INSERT INTO `j_body_notes` VALUES (54, 35, 'li', 28, '男', 1.8, 75.5, 5.6, '126/86', 4.9, 73, 5, 6, '一般', 1, 0, 0, '高蛋白', 1800, '2025-03-10 09:15:25');
INSERT INTO `j_body_notes` VALUES (55, 35, 'li', 28, '男', 1.8, 76, 5.7, '127/87', 5, 74, 5, 6, '一般', 1, 0, 0, '高蛋白', 1700, '2025-03-17 08:45:10');
INSERT INTO `j_body_notes` VALUES (56, 35, 'li', 28, '男', 1.8, 76.5, 5.8, '128/88', 5.1, 75, 5, 5, '较差', 1, 1, 0, '高蛋白', 1700, '2025-03-24 09:30:20');
INSERT INTO `j_body_notes` VALUES (57, 35, 'li', 28, '男', 1.8, 77, 5.9, '130/90', 5.2, 76, 5, 5, '较差', 1, 1, 0, '高蛋白', 1600, '2025-03-31 08:50:15');
INSERT INTO `j_body_notes` VALUES (58, 36, 'zhao', 22, '女', 1.6, 50, 4.9, '105/65', 4, 65, 5, 9, '良好', 0, 0, 1, '低脂饮食', 2200, '2025-03-04 17:10:30');
INSERT INTO `j_body_notes` VALUES (59, 36, 'zhao', 22, '女', 1.6, 50, 4.9, '105/65', 4, 65, 5, 9, '良好', 0, 0, 1, '低脂饮食', 2200, '2025-03-11 16:45:20');
INSERT INTO `j_body_notes` VALUES (60, 36, 'zhao', 22, '女', 1.6, 49.5, 4.8, '104/64', 3.9, 64, 5, 9, '良好', 0, 0, 1, '低脂饮食', 2300, '2025-03-18 17:30:15');
INSERT INTO `j_body_notes` VALUES (61, 36, 'zhao', 22, '女', 1.6, 49, 4.8, '103/63', 3.9, 64, 5, 9, '良好', 0, 0, 1, '低脂饮食', 2300, '2025-03-25 16:20:10');
INSERT INTO `j_body_notes` VALUES (62, 36, 'zhao', 22, '女', 1.6, 48.5, 4.7, '102/62', 3.8, 63, 5, 9, '良好', 0, 0, 1, '低脂饮食', 2400, '2025-04-01 17:15:25');
INSERT INTO `j_body_notes` VALUES (63, 37, 'chen', 35, '男', 1.78, 80, 6, '135/90', 5.2, 78, 5, 6, '一般', 1, 1, 0, '高碳水', 1500, '2025-03-05 11:30:45');
INSERT INTO `j_body_notes` VALUES (64, 37, 'chen', 35, '男', 1.78, 81, 6.1, '136/91', 5.3, 79, 5, 6, '一般', 1, 1, 0, '高碳水', 1500, '2025-03-12 12:15:30');
INSERT INTO `j_body_notes` VALUES (65, 37, 'chen', 35, '男', 1.78, 82, 6.2, '137/92', 5.4, 80, 4, 5, '较差', 1, 1, 0, '高碳水', 1400, '2025-03-19 11:45:20');
INSERT INTO `j_body_notes` VALUES (66, 37, 'chen', 35, '男', 1.78, 83, 6.3, '138/93', 5.5, 81, 4, 5, '较差', 1, 1, 0, '高碳水', 1400, '2025-03-26 12:30:15');
INSERT INTO `j_body_notes` VALUES (67, 37, 'chen', 35, '男', 1.78, 84, 6.4, '140/95', 5.6, 82, 4, 5, '较差', 1, 1, 0, '高碳水', 1300, '2025-04-02 11:50:25');
INSERT INTO `j_body_notes` VALUES (68, 38, 'user', 27, '女', 1.68, 58, 5.1, '115/75', 4.3, 70, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2300, '2025-03-06 13:40:20');
INSERT INTO `j_body_notes` VALUES (69, 38, 'user', 27, '女', 1.68, 57.5, 5, '114/74', 4.2, 69, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2300, '2025-03-13 14:25:15');
INSERT INTO `j_body_notes` VALUES (70, 38, 'user', 27, '女', 1.68, 57, 5, '113/73', 4.2, 69, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2400, '2025-03-20 13:50:30');
INSERT INTO `j_body_notes` VALUES (71, 38, 'user', 27, '女', 1.68, 56.5, 4.9, '112/72', 4.1, 68, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2400, '2025-03-27 14:35:10');
INSERT INTO `j_body_notes` VALUES (72, 38, 'user', 27, '女', 1.68, 56, 4.9, '110/70', 4.1, 68, 5, 8, '良好', 0, 0, 1, '均衡饮食', 2500, '2025-04-03 13:45:25');

-- ----------------------------
-- Table structure for j_health_reminder
-- ----------------------------
DROP TABLE IF EXISTS `j_health_reminder`;
CREATE TABLE `j_health_reminder`  (
  `reminder_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `content` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `reminder_time` datetime NOT NULL,
  `is_read` tinyint(1) NULL DEFAULT 0,
  `type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `priority` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT 'normal',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reminder_id`) USING BTREE,
  INDEX `idx_user_id`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_health_reminder
-- ----------------------------
INSERT INTO `j_health_reminder` VALUES (1, 1, '血压偏高提醒', '您的血压数据显示偏高，建议减少盐分摄入并增加适量运动', '2025-03-17 10:00:00', 0, '血压', 'high', '2025-03-16 08:30:00');
INSERT INTO `j_health_reminder` VALUES (2, 1, '运动提醒', '今天是您的运动日，建议进行30分钟慢跑', '2025-03-17 16:00:00', 1, '运动', 'normal', '2025-03-16 08:30:00');
INSERT INTO `j_health_reminder` VALUES (3, 1, '体检提醒', '您已超过6个月未进行体检，建议尽快安排', '2025-03-20 09:00:00', 1, '体检', 'high', '2025-03-16 08:30:00');
INSERT INTO `j_health_reminder` VALUES (4, 1, '定期上传身体信息', '每周上传一次身体信息，看下分析效果', '2025-03-17 23:20:37', 1, '其他', 'high', '2025-03-17 23:22:20');
INSERT INTO `j_health_reminder` VALUES (5, 39, '血糖偏低提醒', '您的血糖水平略低于正常范围，建议适当增加碳水化合物的摄入', '2025-04-10 08:30:00', 0, '血糖', 'normal', '2025-04-05 10:15:00');
INSERT INTO `j_health_reminder` VALUES (6, 39, '运动建议', '根据您的身体状况，建议每周进行3-4次有氧运动，每次30-45分钟', '2025-04-12 16:00:00', 0, '运动', 'normal', '2025-04-05 10:20:00');
INSERT INTO `j_health_reminder` VALUES (7, 40, '饮食建议', '您的营养摄入良好，建议继续保持均衡饮食，适量增加蛋白质摄入', '2025-04-11 12:00:00', 0, '饮食', 'normal', '2025-04-05 14:30:00');
INSERT INTO `j_health_reminder` VALUES (8, 40, '睡眠提醒', '您的睡眠质量良好，建议保持规律的作息时间，睡前避免使用电子设备', '2025-04-13 21:00:00', 0, '睡眠', 'normal', '2025-04-05 14:35:00');
INSERT INTO `j_health_reminder` VALUES (9, 41, '戒烟提醒', '吸烟对您的健康有严重危害，建议尽快戒烟或寻求专业戒烟帮助', '2025-04-10 10:00:00', 0, '生活习惯', 'high', '2025-04-05 09:00:00');
INSERT INTO `j_health_reminder` VALUES (10, 41, '血压提醒', '您的血压略高于正常范围，建议减少盐分摄入，增加有氧运动', '2025-04-12 09:30:00', 0, '血压', 'high', '2025-04-05 09:05:00');
INSERT INTO `j_health_reminder` VALUES (11, 42, '体重管理', '您的体重指数处于理想范围，建议继续保持健康的饮食和运动习惯', '2025-04-11 15:00:00', 0, '体重', 'normal', '2025-04-05 17:20:00');
INSERT INTO `j_health_reminder` VALUES (12, 42, '水分摄入提醒', '您的水分摄入良好，建议继续保持每天2000-2500ml的水分摄入', '2025-04-13 14:00:00', 0, '饮水', 'normal', '2025-04-05 17:25:00');
INSERT INTO `j_health_reminder` VALUES (13, 43, '综合健康警告', '您的多项健康指标偏离正常范围，建议尽快进行全面体检', '2025-04-10 09:00:00', 0, '体检', 'high', '2025-04-05 11:40:00');
INSERT INTO `j_health_reminder` VALUES (14, 43, '生活方式改善建议', '建议戒烟限酒，增加运动量，改善饮食结构，每天保证充足睡眠', '2025-04-12 08:00:00', 0, '生活习惯', 'high', '2025-04-05 11:45:00');
INSERT INTO `j_health_reminder` VALUES (15, 33, '运动提醒', '根据您的身体状况，建议增加力量训练，每周2-3次，每次30分钟', '2025-04-11 17:30:00', 0, '运动', 'normal', '2025-04-05 13:50:00');
INSERT INTO `j_health_reminder` VALUES (16, 33, '健康饮食提醒', '您的饮食结构良好，建议适当增加蔬果摄入，保证每日五种颜色的蔬果', '2025-04-13 12:30:00', 0, '饮食', 'normal', '2025-04-05 13:55:00');

-- ----------------------------
-- Table structure for j_menu
-- ----------------------------
DROP TABLE IF EXISTS `j_menu`;
CREATE TABLE `j_menu`  (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `component` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `redirect` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `is_leaf` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `hidden` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_menu
-- ----------------------------
INSERT INTO `j_menu` VALUES (1, 'Layout', '/sys', '/sys/user', 'sysManage', '系统管理', 'el-icon-s-order\r\n', 0, 'N', 0);
INSERT INTO `j_menu` VALUES (2, 'sys/user', 'user', NULL, 'userList', '用户管理', 'user', 1, 'Y', 0);
INSERT INTO `j_menu` VALUES (3, 'sys/role', 'role', NULL, 'roleList', '角色管理', 'el-icon-user', 1, 'Y', 0);
INSERT INTO `j_menu` VALUES (4, 'Layout', '/config', '/config/shangchuanxinxi', 'test', '系统功能', 'form', 0, 'N', 0);
INSERT INTO `j_menu` VALUES (5, 'test/test1', 'shangchuanxinxi', '', 'test1', '身体信息上传', 'form', 4, 'Y', 0);
INSERT INTO `j_menu` VALUES (6, 'test/test2', 'jiankangpinggu', '', 'test2', '健康评估', 'el-icon-first-aid-kit', 4, 'Y', 0);
INSERT INTO `j_menu` VALUES (7, 'test/test3', 'yundongzhishi', '', 'test3', '运动知识', 'el-icon-s-opportunity\r\n', 4, 'Y', 0);
INSERT INTO `j_menu` VALUES (8, 'sys/sportDetails', 'sportDetails', '', 'sportDetails', '运动知识管理', 'el-icon-s-opportunity\r\nel-icon-s-custom', 1, 'Y', 0);
INSERT INTO `j_menu` VALUES (9, 'sys/DetailsManage', 'DetailsManage', NULL, 'DetailsManage', '运动详情管理', 'el-icon-s-check', 1, 'Y', 0);
INSERT INTO `j_menu` VALUES (10, 'sys/userBodyManage', 'userBodyManage', NULL, 'userBodyManage', '用户身体信息管理', 'el-icon-s-check', 1, 'Y', 0);
INSERT INTO `j_menu` VALUES (11, 'test/bodyManage', 'bodyManage', NULL, 'bodyManage', '身体信息管理', 'el-icon-s-check', 4, 'Y', 0);
INSERT INTO `j_menu` VALUES (13, 'test/healthReminder', 'healthReminder', NULL, 'healthReminder', '健康提醒', 'el-icon-bell', 4, 'Y', 0);
INSERT INTO `j_menu` VALUES (14, 'mental-health/test', 'xinli-test', NULL, 'MentalHealthTest', '心理健康检测', 'el-icon-user', 4, 'Y', 0);

-- ----------------------------
-- Table structure for j_role
-- ----------------------------
DROP TABLE IF EXISTS `j_role`;
CREATE TABLE `j_role`  (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `role_desc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_role
-- ----------------------------
INSERT INTO `j_role` VALUES (1, 'admin', '超级管理员');
INSERT INTO `j_role` VALUES (3, 'normal', '普通用户');

-- ----------------------------
-- Table structure for j_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `j_role_menu`;
CREATE TABLE `j_role_menu`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NULL DEFAULT NULL,
  `menu_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 237 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_role_menu
-- ----------------------------
INSERT INTO `j_role_menu` VALUES (217, 3, 4);
INSERT INTO `j_role_menu` VALUES (218, 3, 5);
INSERT INTO `j_role_menu` VALUES (219, 3, 6);
INSERT INTO `j_role_menu` VALUES (220, 3, 7);
INSERT INTO `j_role_menu` VALUES (221, 3, 11);
INSERT INTO `j_role_menu` VALUES (222, 3, 13);
INSERT INTO `j_role_menu` VALUES (223, 3, 14);
INSERT INTO `j_role_menu` VALUES (224, 1, 1);
INSERT INTO `j_role_menu` VALUES (225, 1, 2);
INSERT INTO `j_role_menu` VALUES (226, 1, 3);
INSERT INTO `j_role_menu` VALUES (227, 1, 8);
INSERT INTO `j_role_menu` VALUES (228, 1, 9);
INSERT INTO `j_role_menu` VALUES (229, 1, 10);
INSERT INTO `j_role_menu` VALUES (230, 1, 4);
INSERT INTO `j_role_menu` VALUES (231, 1, 5);
INSERT INTO `j_role_menu` VALUES (232, 1, 6);
INSERT INTO `j_role_menu` VALUES (233, 1, 7);
INSERT INTO `j_role_menu` VALUES (234, 1, 11);
INSERT INTO `j_role_menu` VALUES (235, 1, 13);
INSERT INTO `j_role_menu` VALUES (236, 1, 14);

-- ----------------------------
-- Table structure for j_user
-- ----------------------------
DROP TABLE IF EXISTS `j_user`;
CREATE TABLE `j_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `status` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `avatar` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `deleted` int NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_user
-- ----------------------------
INSERT INTO `j_user` VALUES (1, 'admin', '123456', '13343243242', NULL, 'super@aliyun.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 0);
INSERT INTO `j_user` VALUES (33, 'user', '123456', '123456789456', NULL, '2015@qq.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 0);
INSERT INTO `j_user` VALUES (34, 'zhang', '123456', '13812345678', NULL, 'zhang@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 0);
INSERT INTO `j_user` VALUES (35, 'wang', '123456', '13912345678', NULL, 'wang@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 0);
INSERT INTO `j_user` VALUES (36, 'li', '123456', '13712345678', NULL, 'li@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 1);
INSERT INTO `j_user` VALUES (37, 'zhao', '123456', '13612345678', NULL, 'zhao@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 0);
INSERT INTO `j_user` VALUES (38, 'chen', '123456', '13512345678', NULL, 'chen@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 0);
INSERT INTO `j_user` VALUES (39, 'zhang', '123456', '13812345678', NULL, 'zhang@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 0);
INSERT INTO `j_user` VALUES (40, 'wang', '123456', '13912345678', NULL, 'wang@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 1);
INSERT INTO `j_user` VALUES (41, 'li', '123456', '13712345678', NULL, 'li@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 1);
INSERT INTO `j_user` VALUES (42, 'zhao', '123456', '13612345678', NULL, 'zhao@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 1);
INSERT INTO `j_user` VALUES (43, 'chen', '123456', '13512345678', NULL, 'chen@example.com', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 1);
INSERT INTO `j_user` VALUES (44, 'jj', '123456', NULL, NULL, '', 'https://img2.baidu.com/it/u=3618236253,1028428296&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 1);

-- ----------------------------
-- Table structure for j_user_role
-- ----------------------------
DROP TABLE IF EXISTS `j_user_role`;
CREATE TABLE `j_user_role`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `role_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 61 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of j_user_role
-- ----------------------------
INSERT INTO `j_user_role` VALUES (12, 11, 3);
INSERT INTO `j_user_role` VALUES (13, 12, 1);
INSERT INTO `j_user_role` VALUES (45, 54, 3);
INSERT INTO `j_user_role` VALUES (46, 55, 3);
INSERT INTO `j_user_role` VALUES (47, 56, 3);
INSERT INTO `j_user_role` VALUES (49, 1, 1);
INSERT INTO `j_user_role` VALUES (50, 6, 1);
INSERT INTO `j_user_role` VALUES (51, 13, 3);
INSERT INTO `j_user_role` VALUES (52, 14, 1);
INSERT INTO `j_user_role` VALUES (53, 29, 3);
INSERT INTO `j_user_role` VALUES (56, 31, 3);
INSERT INTO `j_user_role` VALUES (59, 33, 3);
INSERT INTO `j_user_role` VALUES (60, 39, 3);

-- ----------------------------
-- Table structure for mental_health
-- ----------------------------
DROP TABLE IF EXISTS `mental_health`;
CREATE TABLE `mental_health`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '用户ID',
  `total_score` int NOT NULL COMMENT '总分',
  `depression_level` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '抑郁程度（无抑郁症状/轻度抑郁/中度抑郁/重度抑郁）',
  `recommendation` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '建议',
  `test_date` datetime NULL DEFAULT NULL COMMENT '测试日期',
  `answers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '答案JSON',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_user_id`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '心理健康测试表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mental_health
-- ----------------------------
INSERT INTO `mental_health` VALUES (4, 1, 63, '中度抑郁', '建议寻求心理咨询师的专业帮助，学习一些减压和情绪管理技巧。', '2025-04-05 16:05:33', '[4,4,4,4,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]');
INSERT INTO `mental_health` VALUES (5, 1, 63, '中度抑郁', '建议寻求心理咨询师的专业帮助，学习一些减压和情绪管理技巧。', '2025-04-05 16:05:34', '[4,4,4,4,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]');
INSERT INTO `mental_health` VALUES (6, 1, 67, '中度抑郁', '建议寻求心理咨询师的专业帮助，学习一些减压和情绪管理技巧。', '2025-06-05 17:11:15', '[1,2,2,2,2,2,2,2,2,4,1,2,4,1,2,2,2,2,1,2]');
INSERT INTO `mental_health` VALUES (7, 1, 67, '中度抑郁', '建议寻求心理咨询师的专业帮助，学习一些减压和情绪管理技巧。', '2025-06-05 17:11:15', '[1,2,2,2,2,2,2,2,2,4,1,2,4,1,2,2,2,2,1,2]');
INSERT INTO `mental_health` VALUES (8, 39, 25, '轻度抑郁', '建议适当放松心情，增加户外活动和社交互动，保持良好的心态。', '2025-04-01 10:30:15', '[2,1,1,2,1,1,2,1,1,2,1,1,2,1,1,1,1,1,1,1]');
INSERT INTO `mental_health` VALUES (9, 40, 15, '无抑郁症状', '您的心理状态良好，建议继续保持积极乐观的生活态度。', '2025-04-02 14:45:20', '[1,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,0,1,0,1]');
INSERT INTO `mental_health` VALUES (10, 41, 45, '中度抑郁', '建议适当调整生活节奏，学习压力管理技巧，必要时寻求专业心理咨询。', '2025-04-03 09:15:30', '[3,2,2,3,2,2,3,2,2,3,2,2,2,3,2,2,2,2,2,2]');
INSERT INTO `mental_health` VALUES (11, 42, 10, '无抑郁症状', '您的心理健康状况非常好，建议继续保持良好的生活习惯和积极心态。', '2025-04-04 16:50:25', '[0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,0,1,0,1,0]');
INSERT INTO `mental_health` VALUES (12, 43, 70, '重度抑郁', '您的心理健康状况需要关注，强烈建议寻求专业心理医生的帮助和治疗。', '2025-04-05 11:25:40', '[4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3]');
INSERT INTO `mental_health` VALUES (13, 33, 20, '轻度抑郁', '建议增加放松活动，保持规律作息，适当进行心理调适。', '2025-04-06 13:40:35', '[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2]');
INSERT INTO `mental_health` VALUES (14, 39, 22, '轻度抑郁', '建议多参与社交活动，保持积极心态，适当进行心理放松训练。', '2025-04-06 10:35:20', '[1,1,1,2,1,1,1,2,1,1,1,1,2,1,1,1,1,1,1,1]');
INSERT INTO `mental_health` VALUES (15, 1, 53, '轻度抑郁', '建议适当放松，多进行户外活动，注意休息，保持规律作息。', '2025-06-05 23:18:37', '[1,1,2,3,2,3,2,3,2,4,2,4,2,4,2,4,2,4,2,4]');
INSERT INTO `mental_health` VALUES (16, 1, 63, '中度抑郁', '建议寻求心理咨询师的专业帮助，学习一些减压和情绪管理技巧。', '2025-06-05 23:23:11', '[2,2,2,3,2,1,1,2,3,3,2,3,2,3,2,3,2,1,1,1]');
INSERT INTO `mental_health` VALUES (17, 1, 53, '轻度抑郁', '建议适当放松，多进行户外活动，注意休息，保持规律作息。', '2025-06-05 23:26:39', '[2,4,2,2,4,2,4,2,4,1,4,1,4,3,2,3,2,4,1,4]');

-- ----------------------------
-- Table structure for sport_info
-- ----------------------------
DROP TABLE IF EXISTS `sport_info`;
CREATE TABLE `sport_info`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `sport_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `suitable_time` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `suitable_heart_rate` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `suitable_frequency` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `recommended_speed` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 37 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sport_info
-- ----------------------------
INSERT INTO `sport_info` VALUES (1, '越野跑', '33分钟', '130-160次/分', '3-4次/周', '8km/h');
INSERT INTO `sport_info` VALUES (3, '瑜伽', '60分钟', '90-110次/分', '1-2次/周', '无');
INSERT INTO `sport_info` VALUES (4, '羽毛球', '120分钟', '130-150次/分', '3-4次/周', '无');
INSERT INTO `sport_info` VALUES (5, '慢跑', '60分钟', '130-150次/分', '3-4次/周', '8km/h');
INSERT INTO `sport_info` VALUES (10, '跑步', '45分钟', '140-160次/分', '4-5次/周', '10km/h');
INSERT INTO `sport_info` VALUES (13, '太极拳', '60分钟', '80-100次/分', '3-4次/周', '无');
INSERT INTO `sport_info` VALUES (14, '足球', '90分钟', '130-150次/分', '2-3次/周', '无');
INSERT INTO `sport_info` VALUES (15, '快跑', '30分钟', '130-150次/分', '5-6次/周', '13km/h');
INSERT INTO `sport_info` VALUES (16, '爬山', '60分钟', '130-150次/分', '2-3次/周', '5km/h');
INSERT INTO `sport_info` VALUES (18, '游泳', '45分钟', '120-140次/分', '3-4次/周', '2.5km/h');
INSERT INTO `sport_info` VALUES (19, '篮球', '120分钟', '130-150次/分', '1-2次/周', '无');
INSERT INTO `sport_info` VALUES (20, '排球', '1小时', '100-120次/分钟', '2-3次/周', '无');
INSERT INTO `sport_info` VALUES (21, '网球', '1.5小时', '100-130次/分钟', '2-3次/周', '无');
INSERT INTO `sport_info` VALUES (22, '滑冰', '1小时', '100-120次/分钟', '2-3次/周', '10-15千米/小时');
INSERT INTO `sport_info` VALUES (23, '长跑', '30分钟-1小时', '120-160次/分钟', '3-4次/周', '10-15千米/小时');
INSERT INTO `sport_info` VALUES (24, '橄榄球', '1.5-2小时', '100-120次/分钟', '2-3次/周', '无');
INSERT INTO `sport_info` VALUES (25, '跆拳道', '1小时', '120-140次/分钟', '3-4次/周', '无');
INSERT INTO `sport_info` VALUES (26, '体操', '1-2小时', '100-120次/分钟', '3-4次/周', '无');
INSERT INTO `sport_info` VALUES (27, '跳高', '1小时', '120-160次/分钟', '2-3次/周', '无');
INSERT INTO `sport_info` VALUES (28, '跳板', '1小时', '120-160次/分钟', '2-3次/周', '无');
INSERT INTO `sport_info` VALUES (29, '跳皮筋', '30分钟-1小时', '100-120次/分钟', '3-4次/周', '无');
INSERT INTO `sport_info` VALUES (30, '跳绳', '30分钟-1小时', '120-160次/分钟', '3-4次/周', '无');
INSERT INTO `sport_info` VALUES (31, '踢毽子', '30分钟-1小时', '100-120次/分钟', '3-4次/周', '无');
INSERT INTO `sport_info` VALUES (32, '放风筝', '1-2小时', '80-100次/分钟', '1-2次/周', '无');
INSERT INTO `sport_info` VALUES (33, '拔河', '30分钟-1小时', '100-120次/分钟', '2-3次/周', '无');
INSERT INTO `sport_info` VALUES (34, '抽陀螺', '30分钟-1小时', '80-100次/分钟', '1-2次/周', '无');
INSERT INTO `sport_info` VALUES (35, '抖空竹', '30分钟-1小时', '80-100次/分钟', '1-2次/周', '无');
INSERT INTO `sport_info` VALUES (36, '扔沙袋', '30分钟-1小时', '100-120次/分钟', '2-3次/周', '无');

SET FOREIGN_KEY_CHECKS = 1;
