# 个人健康管理系统

前后端分离的健康数据管理平台，包含登录鉴权、基于角色的动态菜单权限，以及体征数据、运动记录、心理健康测评、健康提醒等业务模块。

- **技术栈**：Spring Boot、MyBatis-Plus、MySQL、Redis、JWT、Swagger / Vue 2、Element UI
- **类型**：Web 全栈课程设计
- **目录**：`health.sql` 建表脚本；`源码/Health-Management/x-admin` 后端；`源码/Health-Management/x-admin-web` 前端

## 本地运行

```bash
mysql -u root -p < health.sql
cd 源码/Health-Management/x-admin
# 修改 src/main/resources/application.yml 中的数据库与 Redis 连接
mvn spring-boot:run
cd ../x-admin-web
npm install && npm run dev
```

## 说明

前端基于开源 `vue-admin-template` 改造，业务页面与权限模块为自行开发。依赖目录（node_modules、target）未打包，首次运行需 Maven / npm 联网下载依赖。
