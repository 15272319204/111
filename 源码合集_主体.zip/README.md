# 个人项目源码集

计算机科学与技术（本科）课程设计 / 实训项目源码整理，共 7 个项目。

本仓库**只收录源码、配置文件、素材与说明文档**，已移除 `node_modules`、`.venv`、`build`、`bin/obj`、`target`、`.gradle`、IDE 配置等依赖与编译产物；并对代码中的 API Key、本机用户路径做了脱敏处理。

## 项目索引

| 目录 | 项目 | 技术栈 | 类型 |
| --- | --- | --- | --- |
| `01-health-management` | 个人健康管理系统 | Spring Boot / MyBatis-Plus / MySQL / Redis / JWT / Vue | Web 全栈 |
| `02-android-news-app` | 新闻资讯 Android 客户端 | Kotlin / MVVM / Retrofit / Room | 移动端 |
| `03-amap-api-testing` | 高德地图 API 自动化测试 | pytest / requests / Selenium / Locust / JMeter | 软件测试 |
| `04-aspnet-mvc-grades` | 学生成绩管理系统 | ASP.NET Core MVC / EF Core / Identity | .NET Web |
| `05-aircraft-wars-pygame` | 飞机大战 | Python / pygame | 桌面小游戏 |
| `06-wechat-miniprogram` | 微信小程序应用 | 小程序原生 / Node.js | 小程序 |
| `07-ai-voice-training` | 语音交互实训系统 | C / Python / 讯飞 SDK / framebuffer | 嵌入式实训 |

## 本地运行

每个项目目录下的 `README.md` 都写明了依赖、启动命令和注意事项。通用前提：本机需装对应运行环境（JDK + Maven、Node.js、Python 3、Android Studio / .NET 9 SDK、Linux + GCC 等），依赖需要联网重新下载。

`03-amap-api-testing/reports/` 内有 3 份真实 HTML 测试报告，下载后用浏览器打开即可查看运行结果。

## 说明

- 项目均为课程 / 实训作品，用于学习展示，前端管理后台基于 `vue-admin-template` 改造，业务模块为自行开发。
- 涉及第三方服务（高德地图、讯飞语音、新闻 API）的凭证均为占位或需自行申请，不包含真实密钥。
- 若发现配置文件中仍有本机环境相关信息，请按各项目 README 修改后再运行。
