using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MvcGrades.Data;
using MvcGrades.Models;
using Microsoft.EntityFrameworkCore;
namespace MvcGrades.Pages.Account
{
    [AllowAnonymous]
    public class RegisterModel : PageModel
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly ILogger<RegisterModel> _logger;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly ApplicationDbContext _context;
        public RegisterModel(
        UserManager<IdentityUser> userManager,
        SignInManager<IdentityUser> signInManager,
        RoleManager<IdentityRole> roleManager,
        ILogger<RegisterModel> logger,
        ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _logger = logger;
            _context = context;
        }
        public string? ReturnUrl { get; set; }
        [Required]
        [EmailAddress]
        [Display(Name = "����")]
        [BindProperty]
        public string Email { get; set; } = "";
        [Required]
        [StringLength(100, ErrorMessage = "{0} �������ٰ��� {2} ���ַ���",
        MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "����")]
        [BindProperty]
        public string Password { get; set; } = "";
        [DataType(DataType.Password)]
        [Display(Name = "ȷ������")]
        [Compare("Password", ErrorMessage = "�����ȷ�����벻ƥ�䡣")]
        [BindProperty]
        public string ConfirmPassword { get; set; } = "";
        [Display(Name = "��������ѡ��")]
        [BindProperty]
        public string? FullName { get; set; }
        [Display(Name = "ѧ�ţ���ѡ��")]
        [BindProperty]
        public string? StudentNumber { get; set; }
        public void OnGet(string? returnUrl = null)
        {
            ReturnUrl = returnUrl ?? Url.Content("~/");
        }
        public async Task<IActionResult> OnPostAsync(string? returnUrl = null)
        {
            returnUrl ??= Url.Content("~/");
            if (!ModelState.IsValid) return Page();
            var user = new IdentityUser
            {
                UserName = Email,
                Email = Email,
                EmailConfirmed = true
            };
            var result = await _userManager.CreateAsync(user, Password);
            if (result.Succeeded)
            {
                _logger.LogInformation("�û��Ѵ�����");
                // ���԰����û����� Student ��ɫ��������ڣ�
                if (await _roleManager.RoleExistsAsync("Student"))
                {
                    await _userManager.AddToRoleAsync(user, "Student");
                }
                // �����д��ѧ�ţ����� Student ������һ��������¼���� Identity �û���Student ������
if (!string.IsNullOrWhiteSpace(StudentNumber))
                {
                    // ����Ƿ�����ͬѧ�Ż��������û������� Student��ȷ��һ��һ��
                    var existing = await _context.Students
                    .FirstOrDefaultAsync(s => s.StudentNumber ==
                    StudentNumber || s.UserId == user.Id);
                    if (existing != null)
                    {
                        // ������м�¼��δ�����û�������������������������Ϣ
                        existing.UserId = user.Id;
                        existing.Name = string.IsNullOrWhiteSpace(FullName) ?
                        Email : FullName;
                        _context.Students.Update(existing);
                    }
                    else
                    {
                        var student = new Student
                        {
                            Name = string.IsNullOrWhiteSpace(FullName) ? Email :
                        FullName,
                            StudentNumber = StudentNumber,
                            UserId = user.Id
                        };
                        _context.Students.Add(student);
                    }
                    await _context.SaveChangesAsync();
                }
                // ��¼
                await _signInManager.SignInAsync(user, isPersistent: false);
                return LocalRedirect(returnUrl);
            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
            return Page();
        }
    }
}